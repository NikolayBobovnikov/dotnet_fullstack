﻿
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace ListSerializer
{
    public class ListNode
    {
        public ListNode Previous;
        public ListNode Next;
        public ListNode Random;
        public string Data;
    }

    public struct ListNodeData{
        public string Data;
    }

    public class ListRandom
    {
        public ListNode Head;
        public ListNode Tail;
        public int Count;

        public void Serialize(Stream s)
        {
            var tSpan = MemoryMarshal.CreateSpan(ref Count, 1);
            var span = MemoryMarshal.AsBytes(tSpan);
            s.Write(span);
        }

        public void Deserialize(Stream s)
        {

        }
    }

    public static class Extensions
    {
        public static void Serialize(this ListNode node, Stream s)
        {
            s.Write<ListNodeData>(new ListNodeData(){Data = node.Data});
        }

        public static void Deserialize(this Stream s)
        {

        }

        public static void Write<T>(this Stream stream, T value)
            where T : unmanaged
        {
            var tSpan = MemoryMarshal.CreateSpan(ref value, 1);
            var span = MemoryMarshal.AsBytes(tSpan);
            stream.Write(span);
        }

        public static T Read<T>(this Stream stream)
            where T : unmanaged
        {
            var result = default(T);
            var tSpan = MemoryMarshal.CreateSpan(ref result, 1);
            var span = MemoryMarshal.AsBytes(tSpan);
            stream.Read(span);
            return result;
        }

        public static string ReadString(this Stream stream)
    {
        var length = stream.Read<int>();
        return string.Create(length, stream, (chars, streamToUse) =>
        {
            var bytes = MemoryMarshal.AsBytes(chars);
            streamToUse.Read(bytes);
        });
    }

    }
}
